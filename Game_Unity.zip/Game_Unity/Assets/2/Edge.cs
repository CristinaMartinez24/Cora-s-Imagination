using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Edge 
{

    public int vertexA; // nodoA de la arista
    public int vertexB; // nodoB de la arista
    public float volume;
    public int vertexOther; // nodo del triangulo que no forma parte de la arista, opuesto

    // Constructor
    public Edge(int vertexA, int vertexB, float volume)
    {
        this.vertexA = vertexA;
        this.vertexB = vertexB;
        this.volume = volume;
    }

    public Edge(int vertexA, int vertexB, int vertexOther)
    {
        this.vertexA = vertexA;
        this.vertexB = vertexB;
        this.vertexOther = vertexOther;
    }


}

// Para poder comparar aristas, para posteriormente ver q no se repitan muelles
public class EdgeComparer : IComparer<Edge>
{
    public int Compare(Edge a, Edge b)
    {
        //Si a es mayor que b
        if (a.vertexA > b.vertexA || a.vertexB > b.vertexB) return 1;
        //Si b es mayor que a
        if (a.vertexA < b.vertexA || a.vertexB < b.vertexB) return -1;
        //Si no
        else return 0;
    }
}
