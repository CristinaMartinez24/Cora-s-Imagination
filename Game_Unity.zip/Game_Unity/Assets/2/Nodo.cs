using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Nodo
{
    public Vector3 pos;
    public Vector3 vel;
    public Vector3 force;
    public bool isFixed;
    public float mass;

    public Nodo(Vector3 pos, bool isFixed, float mass)
    {
        this.mass = mass;
        this.pos = pos;
        this.isFixed = isFixed;
    }

    public void ComputeForces(Vector3 gravity)
    {
        force += mass * gravity; //calcula su masa
    }
    public void ComputeDamping(float damping)
    {
        force -= vel * damping;
    }
    public void ComputeWind(float windFriction, Vector3 windVel, Vector3 n, Vector3 triangleVel)
    {
        float a = n.magnitude / 2;
        force += windFriction * a * (Vector3.Dot(n.normalized, (windVel - triangleVel))) * n;
    }

    public void ComputePenalty(float k, Vector3 u, float delta)
    {
        force += k * delta * u;
    }

    public void actualizarMasa(float masa)
    {
        mass += masa; 
    }
}
