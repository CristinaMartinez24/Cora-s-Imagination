using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pesos
{
    public float peso1;
    public float peso2;
    public float peso3;
    public float peso4;

    public int idx;

    //Pesos de cada nodo y el indice de a que punto de la malla corresponde
    public Pesos(int idx, float peso1, float peso2, float peso3, float peso4)
    {
        this.idx = idx;
        this.peso1 = peso1;
        this.peso2 = peso2;
        this.peso3 = peso3;
        this.peso4 = peso4;
    }
}
