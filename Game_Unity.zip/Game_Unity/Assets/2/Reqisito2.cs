using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

public class Reqisito2 : MonoBehaviour
{
    //Variables
    public bool pause;
    public Integration integrationMode;
    public Vector3 Gravity;
    public float TimeStep;


    // Assets texto
    public TextAsset nodosTexto;
    public TextAsset tetraTextos;

    //Otras variables
    public int substeps = 10;
    public float stiffnessTraccion;
    public float mass = 1.0f;


    // Estructura de objetos
    List<Nodo> nodesList;
    List<Spring> springList;
    List<Tetra> tetrasList;


    public enum Integration
    {
        Explicit = 0,
        Symplectic = 1,
    };


    void Start()
    {
        //Inicializaci�n de variables
        nodesList = new List<Nodo>();
        springList = new List<Spring>();
        tetrasList = new List<Tetra>();
        this.Gravity = new Vector3(0.0f, -9.81f, 0.0f);
        this.TimeStep = 0.01f;

        // Archivoa a leer del TentGen
        string[] archivoTentGen = getTextParser(nodosTexto);
        CultureInfo cultureFloat = new CultureInfo("en-US");

        //Se recorre el txt y se a�aden los distintos nodos a la lista,
        //Se tiene que saltar los tres primeros numeros y el primer numero de cada linea,
        //Por eso i es igual a 5 y se le suma cuatro cada vez a pesar de haber 3 posiciones

        for (int i = 5; i < archivoTentGen.Length; i += 4)
        {
            float x = float.Parse(archivoTentGen[i], cultureFloat);
            float y = float.Parse(archivoTentGen[i + 1], cultureFloat);
            float z = float.Parse(archivoTentGen[i + 2], cultureFloat);

            Vector3 position = new Vector3(x, y, z);
            position = transform.TransformPoint(position);

            Nodo nodo1;
            if (i <= 10)
            {
                nodo1 = new Nodo(position, true, mass);
            }
            else
            {
                nodo1 = new Nodo(position, false, mass);
            }

            nodesList.Add(nodo1);

        }

        archivoTentGen = getTextParser(tetraTextos);

        // 
        for (int i = 4; i < archivoTentGen.Length; i += 5)
        {

            int nodo1 = int.Parse(archivoTentGen[i], cultureFloat) - 1;
            int nodo2 = int.Parse(archivoTentGen[i + 1], cultureFloat) - 1;
            int nodo3 = int.Parse(archivoTentGen[i + 2], cultureFloat) - 1;
            int nodo4 = int.Parse(archivoTentGen[i + 3], cultureFloat) - 1;

            Tetra tetraedro = new Tetra(nodesList[nodo1], nodesList[nodo2], nodesList[nodo3], nodesList[nodo4]);
            tetrasList.Add(tetraedro);

            springList.Add(new Spring(nodesList[nodo1], nodesList[nodo2], stiffnessTraccion,0));
            springList.Add(new Spring(nodesList[nodo1], nodesList[nodo3], stiffnessTraccion,0));
            springList.Add(new Spring(nodesList[nodo1], nodesList[nodo4], stiffnessTraccion,0));
            springList.Add(new Spring(nodesList[nodo2], nodesList[nodo3], stiffnessTraccion,0));
            springList.Add(new Spring(nodesList[nodo2], nodesList[nodo4], stiffnessTraccion,0));
            springList.Add(new Spring(nodesList[nodo3], nodesList[nodo4], stiffnessTraccion,0));

        }

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void FixedUpdate()
    {
        for (int i = 0; i < substeps; i++)
        {
            if (pause)
            {
                return;
            }

            switch (this.integrationMode)
            {
                case Integration.Symplectic: this.stepSymplectic(); break;
                case Integration.Explicit: this.stepExplicit(); break;
                default:
                    throw new System.Exception("ERROR - NUNCA PASA");
            }
        }

    }

    private void stepExplicit()
    {

    }

    // Metodo Symplectico, que calcula todas las fuerzas que afectan a los muelles y nodos
    private void stepSymplectic()
    {
        //  Fuerzas del nodo
        foreach (Nodo node in nodesList)
        {
            node.force = Vector3.zero;
            node.ComputeForces(Gravity);

        }

        // Fuerzas del muelle
        foreach (Spring spring in springList)
        {

            spring.ComputeForces();

        }

        // Actualizamos posiciones y velocidades si no son fijos
        foreach (Nodo node in nodesList)
        {
            if (!node.isFixed)
            {
                node.vel += TimeStep / node.mass * node.force; //calculo velocidad con fuerzas
                node.pos += TimeStep * node.vel; //calculo posicion con velocidades

            }

        }

        // recalcular longitud del muelle
        foreach (Spring spring in springList)
        {

            spring.UpdateLength();

        }

    }

    public void OnDrawGizmos()
    {
        if (nodesList != null)
        {
            foreach (var n in nodesList)
            {
                Gizmos.color = Color.blue;
                Gizmos.DrawSphere(n.pos, 1.0f);
            }
            foreach (var spring in springList)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawLine(spring.nodeA.pos, spring.nodeB.pos);
            }

        }
    }

    private string[] getTextParser(TextAsset file)
    {
        string[] textString = file.text.Split(new string[] { " ", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
        return textString;

    }
}
