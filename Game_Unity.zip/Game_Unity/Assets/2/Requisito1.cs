using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Requisito1 : MonoBehaviour
{

    //Variables
    public bool pause;
    public Integration integrationMode;
    public Vector3 Gravity;
    public float TimeStep;

    public int substeps = 10;
    // public GameObject element;
    public float stiffnessTraccion;
    public float mass = 1.0f;
    public float windFriction;

    List<Nodo> nodesList;
    List<Spring> springList;

    public enum Integration
    {
        Explicit = 0,
        Symplectic = 1,
    };


    void Start()
    {
        mass = 1.0f;
        stiffnessTraccion = 10.0f; 
        //Inicializaci�n de variables
        nodesList = new List<Nodo>();
        springList = new List<Spring>();

        // Mas variables
        this.Gravity = new Vector3(0.0f, -9.81f, 0.0f);
        this.TimeStep = 0.01f;

        Vector3 punto1 = new Vector3(0, 0, 0);
        Vector3 punto2 = new Vector3(8, 0, 0);
        Vector3 punto3 = new Vector3(4, 2, 8);
        Vector3 punto4 = new Vector3(4, 8, 4);

        Nodo node = new Nodo(transform.TransformPoint(punto1), false, mass);
        nodesList.Add(node);
        Nodo node2 = new Nodo(transform.TransformPoint(punto2), false, mass);
        nodesList.Add(node2);
        Nodo node3 = new Nodo(transform.TransformPoint(punto3), false, mass);
        nodesList.Add(node3);
        Nodo node4 = new Nodo(transform.TransformPoint(punto4), true, mass);
        nodesList.Add(node4);

        Spring arista1 = new Spring(node, node2, stiffnessTraccion,0);
        Spring arista2 = new Spring(node, node3, stiffnessTraccion,0);
        Spring arista3 = new Spring(node, node4, stiffnessTraccion, 0);
        Spring arista4 = new Spring(node2, node3, stiffnessTraccion, 0);
        Spring arista5 = new Spring(node2, node4, stiffnessTraccion, 0);
        Spring arista6 = new Spring(node3, node4, stiffnessTraccion,0);

        springList.Add(arista2);
        springList.Add(arista1);
        springList.Add(arista3);
        springList.Add(arista4);
        springList.Add(arista5);
        springList.Add(arista6);

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void FixedUpdate()
    {
        for (int i = 0; i < substeps; i++)
        {
            if (pause)
            {
                return;
            }

            switch (this.integrationMode)
            {
                case Integration.Symplectic: this.stepSymplectic(); break;
                case Integration.Explicit: this.stepExplicit(); break;
                default:
                    throw new System.Exception("ERROR - NUNCA PASA");
            }
        }

    }

    private void stepExplicit()
    {

    }

    // Metodo Symplectico, que calcula todas las fuerzas que afectan a los muelles y nodos
    private void stepSymplectic()
    {
        //  Fuerzas del nodo
        foreach (Nodo node in nodesList)
        {
            node.force = Vector3.zero;
            node.ComputeForces(Gravity);

        }

        // Fuerzas del muelle
        foreach (Spring spring in springList)
        {

            spring.ComputeForces();

        }

        // Actualizamos posiciones y velocidades si no son fijos
        foreach (Nodo node in nodesList)
        {
            if (!node.isFixed)
            {
                node.vel += TimeStep / node.mass * node.force; //calculo velocidad con fuerzas
                node.pos += TimeStep * node.vel; //calculo posicion con velocidades

            }

        }

        // recalcular longitud del muelle
        foreach (Spring spring in springList)
        {

            spring.UpdateLength();

        }

    }

    public void OnDrawGizmos()
    {
        if (nodesList != null)
        {
            foreach (var n in nodesList)
            {
                Gizmos.color = Color.blue;
                Gizmos.DrawSphere(n.pos, 1.0f);
            }
            foreach (var spring in springList)
            {
                Gizmos.color = Color.red;
                Gizmos.DrawLine(spring.nodeA.pos, spring.nodeB.pos);
            }

        }
    }
}
