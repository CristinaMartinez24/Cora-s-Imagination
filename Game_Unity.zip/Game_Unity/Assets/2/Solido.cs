using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using static UnityEditor.PlayerSettings;

public class Solido : MonoBehaviour
{

    //Variables
    public bool pause;
    public Integration integrationMode;
    public Vector3 Gravity;
    public float TimeStep;

    // Assets texto
    public TextAsset nodosTexto;
    public TextAsset tetraTextos;

    //Otras variables
    public GameObject element;
    public float density; // requiso 4
    public float densityStiffness;  // requiso 4
    float stiffnessTraccion;
    float mass = 1.0f;
    // Extra
    public int substeps = 5;
    public float dampingSpring;
    public float dampingNode;
    public float windFriction;
    public Vector3 windVel;
    public float penaltyK;

    // Estructura de objetos
    List<Nodo> nodesList;
    List<Spring> springList;
    List<Tetra> tetrasList;
    List<Edge> edgeList;

    EdgeComparer edgeComparer;

    // Viento no uniforme
    float sen;
    int aux; 

    public enum Integration
    {
        Explicit = 0,
        Symplectic = 1,
    };


    void Start()
    {
        aux = 0;
        sen = 0;
        //Inicializaci�n de variables
        nodesList = new List<Nodo>();
        springList = new List<Spring>();
        tetrasList = new List<Tetra>();
        edgeList =  new List<Edge>();
        edgeComparer = new EdgeComparer();

        this.Gravity = new Vector3(0.0f, -9.81f, 0.0f);
        this.TimeStep = 0.01f;

        // Obtener geometria del plano
        Mesh mesh = this.GetComponentInChildren<MeshFilter>().mesh;

        // Archivoa a leer del TentGen
        string[] archivoTentGen = getTextParser(nodosTexto);
        CultureInfo cultureFloat = new CultureInfo("en-US");

        //Se recorre el txt y se a�aden los distintos nodos a la lista,
        //Se tiene que saltar los tres primeros numeros y el primer numero de cada linea,
        //Por eso i es igual a 5 y se le suma cuatro cada vez a pesar de haber 3 posiciones

        for (int i = 5; i < archivoTentGen.Length; i += 4)
        {
            float x = float.Parse(archivoTentGen[i], cultureFloat);
            float y = float.Parse(archivoTentGen[i + 1], cultureFloat);
            float z = float.Parse(archivoTentGen[i + 2], cultureFloat);

            Vector3 position = new Vector3((x-0.1f)*1.1f, (z - 0.1f) * 1.1f, (y-0.1f)*1.1f);
            position = transform.TransformPoint(position);

            // Si un vertice esta dentro del GameObject ser� fijo
            bool fijo;
            Bounds bounds = element.GetComponent<Collider>().bounds;
            bool isInside = bounds.Contains(position);
            if (isInside) fijo = true; else fijo = false;

            Nodo nodo1 = new Nodo(position, fijo, mass);
            nodesList.Add(nodo1);

        }

        archivoTentGen = getTextParser(tetraTextos);

        // Hacemos lo mismo para los tetraedros y guardamos las aristas
        for (int i = 4; i < archivoTentGen.Length; i += 5)
        {

            int nodo1 = int.Parse(archivoTentGen[i], cultureFloat) - 1;
            int nodo2 = int.Parse(archivoTentGen[i + 1], cultureFloat) - 1;
            int nodo3 = int.Parse(archivoTentGen[i + 2], cultureFloat) - 1;
            int nodo4 = int.Parse(archivoTentGen[i + 3], cultureFloat) - 1;

            Tetra tetraedro = new Tetra(nodesList[nodo1], nodesList[nodo2], nodesList[nodo3], nodesList[nodo4]);
            tetrasList.Add(tetraedro);

            // Repartir la masa del tetraedro entre sus nodos (requisito 3)
            float volumneTetra = tetraedro.volume;
            float m = volumneTetra * density;
            float masaNodo = m / 4;
            tetraedro.nodo1.mass += masaNodo;
            tetraedro.nodo2.mass += masaNodo;
            tetraedro.nodo3.mass += masaNodo;
            tetraedro.nodo4.mass += masaNodo;

            // Los metemos de tal forma que el nodo1 de la arista sea menor que el segundo para luego ordenarlos y poder identificar las repetidas
            if (nodo1 < nodo2)
            {
                edgeList.Add(new Edge(nodo1, nodo2, volumneTetra));
            }
            else
            {
                edgeList.Add(new Edge(nodo2, nodo1, volumneTetra));
            }
            
            if (nodo1 < nodo3)
            {
                edgeList.Add(new Edge(nodo1, nodo3, volumneTetra));
            }
            else
            {
                edgeList.Add(new Edge(nodo3, nodo1, volumneTetra));
            }

            if (nodo1 < nodo4)
            {
                edgeList.Add(new Edge(nodo1, nodo4, volumneTetra));
            }
            else
            {
                edgeList.Add(new Edge(nodo4, nodo1, volumneTetra));
            }

            if (nodo2 < nodo3)
            {
                edgeList.Add(new Edge(nodo2, nodo3, volumneTetra));
            }
            else
            {
                edgeList.Add(new Edge(nodo3, nodo2, volumneTetra));
            }

            if (nodo2 < nodo4)
            {
                edgeList.Add(new Edge(nodo2, nodo4, volumneTetra));
            }
            else
            {
                edgeList.Add(new Edge(nodo4, nodo2, volumneTetra));
            }
            if (nodo3 < nodo4)
            {
                edgeList.Add(new Edge(nodo3, nodo4, volumneTetra));
            }
            else
            {
                edgeList.Add(new Edge(nodo4, nodo3, volumneTetra));
            }

        }

        edgeList.Sort(edgeComparer);

        for (int i = 0; i < edgeList.Count -1; i++)
        {
            //Si la arista i es distinto a la arista i+1, no se repite por lo que se incluye
            if (edgeComparer.Compare(edgeList[i], edgeList[i + 1]) != 0)
            {
                Spring spring = new Spring(nodesList[edgeList[i].vertexA], nodesList[edgeList[i].vertexB], stiffnessTraccion, edgeList[i].volume);
                springList.Add(spring);
            }

            //Como el ultimo no lo mete aun sin repetirse se a�ade al final 
            Spring springLast = new Spring(nodesList[edgeList[edgeList.Count - 1].vertexA], nodesList[edgeList[edgeList.Count - 1].vertexB], stiffnessTraccion, edgeList[edgeList.Count-1].volume);
            springList.Add(springLast);

        }


        // Fuerza bruta para versi un punto p esta dentro de alguno de los tetraedros
        for (int i = 0; i < mesh.vertices.Length; i++)
        {
            for (int j = 0; j < tetrasList.Count; j++)
            {
                float volumeTotal = tetrasList[j].volume;
                Vector3 p = transform.TransformPoint(mesh.vertices[i]);

                if (tetrasList[j].estaDentro(p))
                {
                    //Peso de cada nodo wi con respecto a un vertice de la malla (p), excluyendo pi
                    float peso1 = tetrasList[j].calcularVolumen(p, tetrasList[j].nodo2.pos, tetrasList[j].nodo3.pos, tetrasList[j].nodo4.pos) / volumeTotal;
                    float peso2 = tetrasList[j].calcularVolumen(p, tetrasList[j].nodo1.pos, tetrasList[j].nodo3.pos, tetrasList[j].nodo4.pos) / volumeTotal;
                    float peso3 = tetrasList[j].calcularVolumen(p, tetrasList[j].nodo1.pos, tetrasList[j].nodo2.pos, tetrasList[j].nodo4.pos) / volumeTotal;
                    float peso4 = tetrasList[j].calcularVolumen(p, tetrasList[j].nodo1.pos, tetrasList[j].nodo2.pos, tetrasList[j].nodo3.pos) / volumeTotal;

                    tetrasList[j].vertices.Add(new Pesos(i, peso1, peso2, peso3, peso4));
                }

            }
        }

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void FixedUpdate()
    {
        for (int i = 0; i < substeps; i++)
        {
            if (pause)
            {
                return;
            }

            switch (this.integrationMode)
            {
                case Integration.Symplectic: this.stepSymplectic(); break;
                case Integration.Explicit: this.stepExplicit(); break;
                default:
                    throw new System.Exception("ERROR - NUNCA PASA");
            }

            // Viento no uniforme
            aux++;
            if (aux > 5)
            {
                aux = 0;
                sen += 0.1f;
                if (sen > 2 * System.Math.PI) sen = 0;
            } 

        }

        Mesh mesh = this.GetComponentInChildren<MeshFilter>().mesh;
        Vector3[] vertices = mesh.vertices;

        //Se actualiza la posici�n de la malla real en funci�n de la posici�n de los nodos y su peso.
        foreach (Tetra tetraedro in tetrasList)
        {
            // Por si tienes varios puntos de la maalla dentro
            foreach (var vertice in tetraedro.vertices)
            {
                vertices[vertice.idx] = tetraedro.nodo1.pos * vertice.peso1 + tetraedro.nodo2.pos * vertice.peso2 + tetraedro.nodo3.pos * vertice.peso3 + tetraedro.nodo4.pos * vertice.peso4;
                vertices[vertice.idx] = transform.InverseTransformPoint(vertices[vertice.idx]);

            }
        }

        mesh.vertices = vertices;

    }

    private void stepExplicit()
    {
        print("Cambia al modo simplectico");
    }

    // Metodo Symplectico, que calcula todas las fuerzas que afectan a los muelles y nodos
    private void stepSymplectic()
    {
        //  Fuerzas del nodo
        foreach (Nodo node in nodesList)
        {
            node.force = Vector3.zero;
            node.ComputeForces(Gravity);
            node.ComputeDamping(dampingNode);

            // Colision con el suelo (0,0,0)
            if (node.pos.y < 8.9f)
            {
                Vector3 a = new Vector3(0, 0, 1);
                Vector3 b = new Vector3(1, 0, 0);
                Vector3 n = Vector3.Cross(a, b);
                node.ComputePenalty(penaltyK, n, Vector3.Distance(Vector3.zero, node.pos));
            }

        }

        // Fuerza de viento (no uniforme con la funcion del seno)

        foreach (Tetra t in tetrasList)
        {
            Vector3 triangleVel = (t.nodo1.vel + t.nodo2.vel + t.nodo3.vel) / 3;
            Vector3 n = Vector3.Cross(t.nodo1.pos - t.nodo2.pos, t.nodo3.pos - t.nodo2.pos);

            t.nodo1.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo2.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo3.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);

            triangleVel = (t.nodo2.vel + t.nodo3.vel + t.nodo4.vel) / 3;
            n = Vector3.Cross(t.nodo3.pos - t.nodo2.pos, t.nodo4.pos - t.nodo2.pos);

            t.nodo2.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo3.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo4.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);

            triangleVel = (t.nodo1.vel + t.nodo3.vel + t.nodo4.vel) / 3;
            n = Vector3.Cross(t.nodo1.pos - t.nodo3.pos, t.nodo4.pos - t.nodo3.pos);

            t.nodo1.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo3.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo4.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);

            triangleVel = (t.nodo1.vel + t.nodo2.vel + t.nodo4.vel) / 3;
            n = Vector3.Cross(t.nodo1.pos - t.nodo4.pos, t.nodo2.pos - t.nodo4.pos);

            t.nodo1.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo2.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            t.nodo4.ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
        }

        // Fuerzas del muelle
        foreach (Spring spring in springList)
        {

            spring.ComputeForcesDensity(densityStiffness);
            spring.ComputeDamping(dampingSpring);
        }

        // Actualizamos posiciones y velocidades si no son fijos
        foreach (Nodo node in nodesList)
        {
            if (!node.isFixed)
            {
                node.vel += TimeStep / node.mass * node.force; //calculo velocidad con fuerzas
                node.pos += TimeStep * node.vel; //calculo posicion con velocidades

            }

        }

        // recalcular longitud del muelle
        foreach (Spring spring in springList)
        {

            spring.UpdateLength();

        }

    }

    public void OnDrawGizmos()
    {
        if (nodesList != null)
        {
            foreach (var n in nodesList)
            {
                Gizmos.color = Color.white;
                Gizmos.DrawSphere(n.pos, 1.0f);
            }
            foreach (var spring in springList)
            {
                Gizmos.color = Color.black;
                Gizmos.DrawLine(spring.nodeA.pos, spring.nodeB.pos);
            }

        }
    }

    private string[] getTextParser(TextAsset file)
    {
        string[] textString = file.text.Split(new string[] { " ", "\n", "\r" }, StringSplitOptions.RemoveEmptyEntries);
        return textString;

    }
}

