using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spring
{
    public Nodo nodeA, nodeB;
    public float Length0;
    public float Length;
    public float stiffness;
    public float volume;

    // Constructor
    public Spring(Nodo nodoA, Nodo nodoB, float stiffness, float volume)
    {
        this.nodeA = nodoA;
        this.nodeB = nodoB;
        this.stiffness = stiffness;
        this.volume = volume;
        Start();
    }

    public Spring(Nodo nodoA, Nodo nodoB, float stiffness)
    {
        this.nodeA = nodoA;
        this.nodeB = nodoB;
        this.stiffness = stiffness;
        Start();
    }

    void Start()
    {
        UpdateLength();
        Length0 = Length;

    }

    public void UpdateLength()
    {
        Length = (nodeA.pos - nodeB.pos).magnitude;
    }

    public void ComputeForces()
    {
        Vector3 u = nodeA.pos - nodeB.pos;
        u.Normalize();
        Vector3 force = -stiffness * (Length - Length0) * u; //fuerza elastica
        nodeA.force += force;
        nodeB.force -= force;
    }

    //Requisito 4
    public void ComputeForcesDensity(float density)
    {
        var u = nodeA.pos - nodeB.pos;
        u.Normalize();

        Vector3 force = (((-volume)/Mathf.Pow(Length0, 2)) * (density * (Length - Length0)) * ((u)/Length));

        nodeA.force += force;
        nodeB.force -= force;

    }

    public void ComputeDamping(float damping)
    {
        Vector3 u = nodeA.pos - nodeB.pos;
        u.Normalize();
        Vector3 force = -damping * Vector3.Dot(u, nodeA.vel - nodeB.vel) * u;
        nodeA.force += force;
        nodeB.force -= force;
    }
}

