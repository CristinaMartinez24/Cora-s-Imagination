using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static UnityEditor.PlayerSettings;

public class Tetra : MonoBehaviour
{
    public Nodo nodo1;
    public Nodo nodo2;
    public Nodo nodo3;
    public Nodo nodo4;

    public float volume;

    // Lista de pesos segun cuantos puntos (p) tenga dentro
    public List<Pesos> vertices;

    public Tetra(Nodo nodo1, Nodo nodo2, Nodo nodo3, Nodo nodo4)
    {
        this.nodo1 = nodo1;
        this.nodo2 = nodo2;
        this.nodo3 = nodo3;
        this.nodo4 = nodo4;

        vertices = new List<Pesos>();

        Vector3 n = Vector3.Cross(this.nodo3.pos - this.nodo1.pos, this.nodo4.pos - this.nodo1.pos);
        volume = Mathf.Abs(Vector3.Dot((this.nodo2.pos - this.nodo1.pos), n)) / 6;
    }

    // Calcular volumen del tetraedro
    public float calcularVolumen(Vector3 p0, Vector3 p1, Vector3 p2, Vector3 p3)
    {
        Vector3 n = Vector3.Cross((p2 - p0), (p3 - p0));
        return Mathf.Abs(Vector3.Dot((p1 - p0), n)) / 6;
    }

   
    // Saber si un punto p del mesh esta dentro de un tetraedro (de sus cuatro caras)
    public bool estaDentro(Vector3 pos)
    {
        var normal = Vector3.Cross(this.nodo1.pos - this.nodo2.pos, this.nodo3.pos - this.nodo2.pos);
        var w = Vector3.Dot(pos - this.nodo2.pos, normal) / Vector3.Dot(pos - this.nodo4.pos, normal);

        if (-w > 0)
        {
            normal = Vector3.Cross(this.nodo1.pos - this.nodo3.pos, this.nodo4.pos - this.nodo3.pos);
            w = Vector3.Dot(pos - this.nodo3.pos, normal) / Vector3.Dot(pos - this.nodo2.pos, normal);
            if (-w > 0)
            {
                normal = Vector3.Cross(this.nodo2.pos - this.nodo1.pos, this.nodo4.pos - this.nodo1.pos);
                w = Vector3.Dot(pos - this.nodo2.pos, normal) / Vector3.Dot(pos - this.nodo3.pos, normal);

                if (-w > 0)
                {
                    normal = Vector3.Cross(this.nodo3.pos - this.nodo2.pos, this.nodo4.pos - this.nodo2.pos);
                    w = Vector3.Dot(pos - this.nodo3.pos, normal) / Vector3.Dot(pos - this.nodo1.pos, normal);

                    if (-w  > 0)
                    {
                        return true;
                    }
                }
            }
        }

        return false;


    }
}