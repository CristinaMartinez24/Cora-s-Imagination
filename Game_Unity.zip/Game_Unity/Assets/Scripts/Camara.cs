using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camara : MonoBehaviour
{
    public float velocidadMov = 1f;
    private float velocidadRot = 80.0f;
    private float x, y;

    private Animator anim;

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxis("Horizontal");
        y = Input.GetAxis("Vertical");
        //transform.Rotate(0, (x * velocidadRot * Time.deltaTime), 0);
        transform.Translate(0, 0, (y * velocidadMov * Time.deltaTime));

    }
}
