using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CasaController : MonoBehaviour
{
    private bool Openp1 = false;
    private bool Openp2 = false;
    private bool Openp = false;
    private bool Openv = false;

    private Animator anim; 

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if ((Input.GetKeyUp(KeyCode.P)) && Openp1 == true)
        {
            anim.SetTrigger("Puerta1Cerrada");
            anim.SetTrigger("Volver");
            Openp1 = false;
        }
        else if (Input.GetKeyUp(KeyCode.P))
        {
            anim.SetTrigger("Puerta1Abierta");
            Openp1 = true;
            if (Openv == true) Openv = false;
            if (Openp2 == true) Openp2 = false;
            if (Openp == true) Openp = false;
        }


        if ((Input.GetKeyUp(KeyCode.O)) && Openp2 == true)
        {
            anim.SetTrigger("Puerta2Cerrada");
            anim.SetTrigger("Volver");
            Openp2 = false;
        }
        else if (Input.GetKeyUp(KeyCode.O))
        {
            anim.SetTrigger("Puerta2Abierta");
            Openp2 = true;
            if (Openv == true) Openv = false;
            if (Openp1 == true) Openp1 = false;
            if (Openp == true) Openp = false;
        }


        if ((Input.GetKeyUp(KeyCode.I)) && Openp == true)
        {
            anim.SetTrigger("PuertasCerradas");
            anim.SetTrigger("Volver");
            Openp = false;
        }
        else if (Input.GetKeyUp(KeyCode.I))
        {
            anim.SetTrigger("PuertaAbiertas");
            Openp = true;
            if (Openv == true) Openv= false;
            if (Openp1 == true) Openp1 = false;
            if (Openp2 == true) Openp2 = false;
        }


        if ((Input.GetKeyUp(KeyCode.U)) && Openv == true)
        {
            anim.SetTrigger("VentanasCerradas");
            anim.SetTrigger("Volver");
            Openv = false;
        }
        else if (Input.GetKeyUp(KeyCode.U))
        {
            anim.SetTrigger("VentanasAbiertas");
            Openv = true;
            if (Openp1 == true) Openp1 = false;
            if (Openp2 == true) Openp2 = false;
            if (Openp == true) Openp = false;
        }

    }
}
