using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovementController : MonoBehaviour
{

    public float velocidadMov = 1f;
    private float velocidadRot = 80.0f;
    private float x, y;

    private Animator anim; 

    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        x = Input.GetAxis("Horizontal");
        y = Input.GetAxis("Vertical");

        //if (Mathf.Abs(x) == 0 && Mathf.Abs(y) == 0)
        //{
        //    anim.SetTrigger("Parar");

        //    if (Input.GetKey(KeyCode.LeftControl))
        //    {
        //        anim.SetTrigger("PararCorrer");
        //        if (velocidadMov > 1)
        //            velocidadMov -= 1f;
        //    }

        //}
        //else
        //{

        //    anim.SetTrigger("Caminar");

        //    if (Input.GetKey(KeyCode.LeftShift))
        //    {
        //        anim.SetTrigger("Correr");
        //        if (velocidadMov == 1)
        //        {
        //            velocidadMov += 1f;
        //        }
                

        //    } 

        //    if (Input.GetKey(KeyCode.LeftControl))
        //    {
        //        anim.SetTrigger("PararCorrer");
        //        if (velocidadMov > 1)
        //            velocidadMov -= 1f;
        //    }


        //}

        //if (Input.GetKeyDown(KeyCode.Space))
        //{
        //    anim.SetTrigger("Salto");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha1))
        //{
        //    anim.SetTrigger("Perro");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha2))
        //{
        //    anim.SetTrigger("Saludo");
        //}
       

        //if (anim.GetBool("Sentarse"))
        //{
        //    if (Input.GetKeyDown(KeyCode.Alpha4))
        //    {
        //        anim.SetBool("Sentarse", false);
        //        anim.SetTrigger("Levantarse");
        //    }
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha3))
        //{
        //    anim.SetBool("Sentarse", true);
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha5))
        //{
        //    anim.SetTrigger("Gafas");   
        //}

        

        //if (Input.GetKeyDown(KeyCode.Alpha7))
        //{
        //    anim.SetTrigger("Feliz");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha8))
        //{
        //    anim.SetTrigger("Triste");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha9))
        //{
        //    anim.SetTrigger("Enfado");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha0))
        //{
        //    anim.SetTrigger("Sorpresa");
        //}

        //if (Input.GetKeyDown(KeyCode.Alpha6))
        //{
        //    anim.SetBool("Esquiar", true);
        //}

        transform.Rotate(0,(x*velocidadRot*Time.deltaTime),0);
        transform.Translate(0,0, (y * velocidadMov * Time.deltaTime));

    }
}
