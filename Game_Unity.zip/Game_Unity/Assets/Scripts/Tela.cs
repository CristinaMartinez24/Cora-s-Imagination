using System;
using System.Collections;
using System.Collections.Generic;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.UIElements;
using static Edge;

public class Tela : MonoBehaviour
{
    //Variables
    public bool pause; 
    public Integration integrationMode; 
    public Vector3 Gravity;
    public float TimeStep;

    public int substeps = 10;
    public GameObject element; 
    public float dampingSpring;
    public float dampingNode; 
    public float stiffnessTraccion;
    public float stiffnessFlexion;
    public float mass;
    public float windFriction;
    public Vector3 windVel;

    public float penaltyK;

    List<Nodo> nodesList;
    List<Spring> springList;
    List<Edge> edgesList;
    EdgeComparer edgeComparer;

    // Viento no uniforme
    float sen;
    int aux;

    public enum Integration
    {
        Explicit = 0,
        Symplectic = 1,
    }; 

    void Start()
    {
        aux = 0;
        sen = 0;
        // Inicializaci�n de variables
        nodesList = new List<Nodo>();
        springList = new List<Spring>();
        edgesList = new List<Edge>();

        // Mas variables
        this.Gravity = new Vector3(0.0f, -9.81f, 0.0f);
        this.TimeStep = 0.01f; 
        edgeComparer = new EdgeComparer();

        // Obtener geometria del plano
        Mesh mesh = this.GetComponent<MeshFilter>().mesh;
        Vector3[] vertices = mesh.vertices;
        int[] triangulos = mesh.triangles;

        // Inicializamos un nodo por cada vertice y lo a�adimos a la lista
        foreach (var v in vertices)
        {
            // Si un vertice esta dentro del GameObject ser� fijo
            bool fijo;
            Vector3 pos = transform.TransformPoint(v); // coordenadas globales
            Bounds bounds = element.GetComponent<Collider>().bounds; 
            bool isInside = bounds.Contains(pos);
            if (isInside) fijo = true; else fijo = false;

            Nodo node = new Nodo(pos, fijo, mass);
            nodesList.Add(node); 

        }

        // Obtenemos de 3 en 3 los indices que forman cada triangulo
        for (int i = 0; i < triangulos.Length; i += 3)
        {
            Edge edge;
            Edge edge2;
            Edge edge3; 

            // Miramos que nodo corresponde con cada indice y los comparamos para ordenarlos, de tal forma que 
            // el nodoA de cada arista, siempre va a ser menor que el nodoB,
            // para luego hacer el sort, quedando consecutivas las aristas que son iguales 

            if (triangulos[i] < triangulos[i + 1])
            {
                edge = new Edge(triangulos[i], triangulos[i + 1], triangulos[i + 2]);
            } 
            else
            {
                edge = new Edge(triangulos[i+1], triangulos[i], triangulos[i + 2]);
            }
            if (triangulos[i + 1] < triangulos[i + 2])
            {
                edge2 = new Edge(triangulos[i + 1], triangulos[i + 2], triangulos[i]);
            }
            else
            {
                edge2 = new Edge(triangulos[i + 2], triangulos[i + 1], triangulos[i]);
            }
            if (triangulos[i] < triangulos[i + 2])
            {
                edge3 = new Edge(triangulos[i], triangulos[i + 2], triangulos[i + 1]);
            }
            else
            {
                edge3 = new Edge(triangulos[i+2], triangulos[i], triangulos[i + 1]);
            }
            
            // Introducimos todas las aristas que estar�n repetidas
            edgesList.Add(edge);
            edgesList.Add(edge2);
            edgesList.Add(edge3);
        }

        edgesList.Sort(edgeComparer); //Ordenamos 

        // Vamos a generar los muelles de flexion y de traccion
        for (int i = 0; i < triangulos.Length-1 ; i ++)
        {
            // Si la arista i es igual a la arista i+1, se inicializa un nodo de flexion entre los vertices opuestos a esas aristas (other)
            if (edgeComparer.Compare(edgesList[i], edgesList[i+1])==0)
            {
                Spring springFlex = new Spring(nodesList[edgesList[i].vertexOther], nodesList[edgesList[i+1].vertexOther], stiffnessFlexion);
                springList.Add(springFlex);
            }
            // si las aristas no son iguales se crea uno de traccion en la primera arista , entre sus dos nodos
            else
            {
                Spring springT = new Spring(nodesList[edgesList[i].vertexA], nodesList[edgesList[i].vertexB], stiffnessTraccion);
                springList.Add(springT);
            }
            
        }

        // El for compara una arista con su siguiente, es decir, la ultima no se va a poder comparar con otra,
        // por eso creamos un muelle de traccion con esta ultima arista
        Spring springLast = new Spring(nodesList[edgesList[triangulos.Length - 1].vertexA], nodesList[edgesList[triangulos.Length - 1].vertexB], stiffnessTraccion);
        springList.Add(springLast);
    }

    // Actualizacion de la malla
    void Update()
    {
        Mesh mesh = this.GetComponent<MeshFilter>().mesh;
        Vector3[] vertices = new Vector3[mesh.vertexCount];

        for (int i = 0; i < vertices.Length; i++)
        {
            vertices[i] = transform.InverseTransformPoint(nodesList[i].pos);// se vuelve a cordenadas locales para que unity las pinte bien
        }

        mesh.vertices = vertices; //reescribe para pintarse
    }

    // Actualizacion de fisicas
    public void FixedUpdate()
    {
        for (int i = 0; i< substeps; i++)
        {
            if (pause)
            {
                return; 
            }

            switch (this.integrationMode)
            {
                case Integration.Explicit: this.stepExplicit(); break;
                case Integration.Symplectic: this.stepSymplectic(); break;
                default:
                    throw new System.Exception("ERROR - NUNCA PASA"); 
            }
            this.stepSymplectic();
        }

        // Viento no uniforme
        aux++;
        if (aux > 5)
        {
            aux = 0;
            sen += 0.1f;
            if (sen > 2 * System.Math.PI) sen = 0;
        }

    }


    private void stepExplicit()
    {

    }

    // Metodo Symplectico, que calcula todas las fuerzas que afectan a los muelles y nodos
    private void stepSymplectic()
    {
        //  Fuerzas del nodo
        foreach (Nodo node in nodesList)
        {
            node.force = Vector3.zero;
            node.ComputeForces(Gravity);
            node.ComputeDamping(dampingNode);

            // Colision con el suelo (0,0,0)
            if (node.pos.y < -1.3)
            {
                Vector3 a = new Vector3(0, 0, 1);
                Vector3 b = new Vector3(1, 0, 0);
                Vector3 n = Vector3.Cross(a, b);
                node.ComputePenalty(penaltyK, n, Vector3.Distance(Vector3.zero, node.pos));
            }

        }

        // Fuerzas del muelle
        foreach (Spring spring in springList)
        {

            spring.ComputeForces();
            spring.ComputeDamping(dampingSpring);

        }

        Mesh mesh = this.GetComponent<MeshFilter>().mesh;
        int[] triangulos = mesh.triangles;

        // Fuerzas del Viento
        for (int i = 0; i < triangulos.Length; i += 3)
        {
            Vector3 triangleVel = (nodesList[triangulos[i]].vel + nodesList[triangulos[i + 1]].vel + nodesList[triangulos[i + 2]].vel) / 3;
            Vector3 n = Vector3.Cross(nodesList[triangulos[i + 1]].pos - nodesList[triangulos[i]].pos, nodesList[triangulos[i + 2]].pos - nodesList[triangulos[i]].pos);

            nodesList[triangulos[i]].ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            nodesList[triangulos[i + 1]].ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
            nodesList[triangulos[i + 2]].ComputeWind(windFriction, windVel * (float)System.Math.Sin(sen), n, triangleVel);
        }

        // Actualizamos posiciones y velocidades si no son fijos
        foreach (Nodo node in nodesList)
        {
            if (!node.isFixed)
            {
                node.vel += TimeStep / node.mass * node.force; //calculo velocidad con fuerzas
                node.pos += TimeStep * node.vel; //calculo posicion con velocidades

            }

        }

        // recalcular longitud del muelle
        foreach (Spring spring in springList)
        {

            spring.UpdateLength(); 

        }

    }
}
